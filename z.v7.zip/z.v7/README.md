New SelfBot

>>Require to install<<

=>>pip2 Install rsa

=>>pip2 Install requests

=>>pip2 Install thrift==0.9.3

=>>pip2 install gtts

=>>pip2 install goslate 

=>>pip2 install wikipedia 

=>>pip2 install BeautifulSoup

=>>pip2 install BeautifulSoup4

=>>pip2 install html5

=>>pip2 install tweepy

=>>pip2 install pyowm

=>>Editing by Muhammad Fahmi Ridhani<<=
